package com.example.electframe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import java.util.jar.Manifest

class MainActivity : AppCompatActivity() {

    lateinit var  permissionChecker: PermissionChecker // 초기화를 뒤로 미룸

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val permissions = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        permissionChecker = PermissionChecker(this, permissions)
        if(permissionChecker.check()){
            // 초기화
        }
    }

    private fun init(){

        val adapter = PhotoPagerAdapter(this, listOf<String>())
        viewPager.adapter = adapter
    }
}